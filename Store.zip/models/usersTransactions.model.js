let mongoose = require('mongoose')

let usersTransactions = new mongoose.Schema({    
    userProfileId: {
        type : String
    },
    transactionId: {
        type : String
    }  
})

module.exports = mongoose.model('usersTransactions', usersTransactions)