let mongoose = require('mongoose')

let app_usersSchema = new mongoose.Schema({    
    loginId: {
        type : String
    },
    walletId: {
        type : String
    },
    privateKey:{
        type : String
    }
})

module.exports = mongoose.model('app_users', app_usersSchema)