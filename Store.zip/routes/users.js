var express = require('express');
var router = express.Router();
var JWT = require('jsonwebtoken');
var usersSchemaModel = require('../models/user.model');
var appUsersSchemModel = require('../models/app_users.model');


/* GET users listing. */
router.get('/', function (req, res, next) {
  res.send('respond with a resource');
});

router.post('/addUser', function (req, res, next) {

  usersSchemaModel.find({
    "clientID": req.body.clientID
  }, (err, result) => {
    if (err) {
      res.status(400).send({
        "message": "client id not found"
      })
    } else {
      if (result.length > 0) {
        res.send({
          "message": "user already existed"
        })
      } else {
        let user = new usersSchemaModel({
          clientID: req.body.clientID,
          secretKey: req.body.secretKey,
          status: req.body.status
        })
        user.save()
          .then(doc => {
            console.log(doc);
            res.status(200).send({
              "status": "success",
              "doc": doc
            })
          })
          .catch(err => {
            console.log(err);
            res.status(400).send({
              "msg": "fail"
            })
          })
      }
    }
  });



});



router.post('/addAppUser', function (req, res, next) {
  let user = new appUsersSchemModel({
    loginId: req.body.loginId,
    walletId: req.body.walletId,
    privateKey: req.body.privateKey
  })
  user.save()
    .then(doc => {
      console.log(doc);
      res.status(200).send({
        "status": "success",
        "doc": doc
      })
    })
    .catch(err => {
      console.log(err);
      res.status(400).send({
        "msg": "fail"
      })
    })


});





router.post('/Authenticate', (req, res) => {
  var userObj;
  usersSchemaModel.find({
    "clientID": req.body.clientID
  }, (err, result) => {

    if (err) {
      res.status(500).send({
        "message": "internal server error"
      })
    }
    console.log(result, "_____");
    userObj = result[0];
    if (userObj) {
      if (userObj.secretKey == req.body.password) {
        var user = {
          "secretKey": userObj.secretKey,
          "clientID": userObj.clientID,
          "status": userObj.status
        }
        console.log(userObj, "***********");
        //creating token
        JWT.sign(user, '****', {}, (err, token) => {
          err ? res.json({
            "message": "error while generating token"
          }) : console.log(token);
          res.json({
            token
          });
        })

      } else {
        res.status(400).send({
          "message": "client id not found"
        })
      }
    } else {
      res.status(401).json({
        "message": "Invalid credintials"
      })
    }
  })
})

module.exports = router;