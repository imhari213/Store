let mongoose = require('mongoose')

let usersSchema = new mongoose.Schema({    
    clientID: {
        type : String
    },
    secretKey: {
        type : String
    },
    status:{
        type : String
    }
})

module.exports = mongoose.model('users', usersSchema)