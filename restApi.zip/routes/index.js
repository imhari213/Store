var express = require('express');
var router = express.Router();
const path = require("path");
var JWT = require('jsonwebtoken');
var fs = require('fs');
const file = fs.readFileSync(path.resolve(__dirname, "./../config/web3Config.json"));
const Web3 = require('web3');
const web3configJson = JSON.parse(file);
const SignerProvider = require('ethjs-provider-signer');
const sign = require('ethjs-signer').sign;
const address = web3configJson.accounts[0];
const FaucetPrivateKey = web3configJson.FaucetPrivateKey[0];
var usersSchemaModel = require('../models/user.model');
const provider = new SignerProvider(
  web3configJson.rpc_url,
  {
    signTransaction: (rawTx, cb) =>
      cb(null, sign(rawTx, FaucetPrivateKey)),
    accounts: cb => cb(null, [address])
  }
);
const web3 = new Web3(provider);
const file2 = path.resolve(__dirname, "./../build/contracts/Scm.json");
const parsed = JSON.parse(fs.readFileSync(file2));
const contractaddress = web3configJson.contract_address[0];
const contract = new web3.eth.Contract(parsed.abi, contractaddress);

/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

// uint a,uint _age, string _fName, string _lName
router.post('/setData', verifyToken, function (req, res, next) {

  JWT.verify(req.token, '****', (err, authData) => {
    if (err) {
      console.log(err);
      res.sendStatus(403)
    } else {
      console.log(authData);
      if (authData.status == "active") {

        console.log(req.body.userProfileId);
        var n = JSON.stringify(req.body);
        contract.methods.set(req.body.userProfileId,n)
          .send({
            from: address,
            gas: 9500000
          })
          .on('transactionHash', function (hash) {
            console.log(hash)
          })
          .on('confirmation', function (confirmationNumber, receipt) {
            console.log("Confirmed", confirmationNumber, receipt);
          })
          .on('receipt', function (receipt) {
            res.send(receipt)
          })
          .on("error", function (error) {
            res.send(error);
          });

      }
      else {
        res.send({ "message": "Access denied" })
      }
    }
  });
});


router.post('/getData', verifyToken, function (req, res, next) {
  JWT.verify(req.token, '****', (err, authData) => {
    if (err) {
      console.log(err);
      res.sendStatus(403)
    } else {
      console.log(authData);
      if (authData.status == "active") {
        contract.methods.get(req.body.id).call({
          from: address
        }, (err, result) => {

          if(err){
              res.send(err) 
           }
           else{
             var response = [];
             for(let i=0;i<result.length;i++){
                 response.push(JSON.parse(result[i]));
             }
             console.log(response);
              res.send(response);
           }
        })
      } else {
        res.send({ "message": "Access denied" });
      }
    }
  });
});



function verifyToken(req, res, next) {
  var bearerheader = req.headers['authorization'];
  console.log(bearerheader);
  if (typeof bearerheader !== undefined) {
    console.log("in");
    const Bearer = bearerheader.split(' ');
    const beareToken = Bearer[1];
    req.token = beareToken;
    next()
  } else {
    res.sendStatus(403);
  }
}


module.exports = router;
